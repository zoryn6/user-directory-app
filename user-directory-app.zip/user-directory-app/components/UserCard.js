function getInitials(name) {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0].toUpperCase())
    .join("");
}

// Receives a single user object through props.
export default function UserCard({ user }) {
  const { id, name, username, email, phone, website, address, company } = user;

  return (
    <article className="user-card">
      <div className="avatar" style={{ "--hue": (id * 47) % 360 }} aria-hidden="true">
        {getInitials(name)}
      </div>

      <h3 className="user-name">{name}</h3>
      <p className="user-username">@{username}</p>

      <dl className="user-details">
        <div className="detail">
          <dt>Email</dt>
          <dd>
            <a href={`mailto:${email}`}>{email}</a>
          </dd>
        </div>
        <div className="detail">
          <dt>Phone</dt>
          <dd>{phone}</dd>
        </div>
        <div className="detail">
          <dt>Website</dt>
          <dd>
            <a href={`https://${website}`} target="_blank" rel="noopener noreferrer">
              {website}
            </a>
          </dd>
        </div>
        <div className="detail">
          <dt>City</dt>
          <dd>{address.city}</dd>
        </div>
        <div className="detail">
          <dt>Company</dt>
          <dd>{company.name}</dd>
        </div>
      </dl>
    </article>
  );
}
