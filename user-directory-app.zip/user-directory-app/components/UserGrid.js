import UserCard from "./UserCard";

// Receives the users array through props and renders one UserCard per user.
export default function UserGrid({ users }) {
  if (!users || users.length === 0) {
    return (
      <div className="empty-state" role="status">
        <p className="empty-title">No users found</p>
        <p className="empty-text">The API returned an empty list. Try again later.</p>
      </div>
    );
  }

  return (
    <div className="user-grid">
      {users.map((user) => (
        <UserCard key={user.id} user={user} />
      ))}
    </div>
  );
}
