import UserGrid from "../components/UserGrid";

const USERS_API_URL = "https://jsonplaceholder.typicode.com/users";

// Runs on the server only: this page is an async React Server Component.
async function getUsers() {
  const response = await fetch(USERS_API_URL, {
    next: { revalidate: 3600 }, // cache the response, refresh at most once an hour
  });

  if (!response.ok) {
    // Thrown errors are caught by app/error.js
    throw new Error(`The users API responded with status ${response.status}.`);
  }

  return response.json();
}

export default async function HomePage() {
  const users = await getUsers();

  return (
    <main className="page">
      <header className="page-header">
        <h1 className="page-title">User Directory</h1>
        <p className="page-subtitle">
          Profile cards rendered on the server from a live API. The data is
          fetched once on the server and passed down to components as props.
        </p>
      </header>

      <section aria-labelledby="users-heading">
        <h2 id="users-heading" className="section-title">
          All users <span className="count">{users.length}</span>
        </h2>
        <UserGrid users={users} />
      </section>
    </main>
  );
}
