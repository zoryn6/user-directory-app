// Shown automatically by Next.js while the page's server-side fetch is pending.
export default function Loading() {
  return (
    <main className="page" aria-busy="true">
      <header className="page-header">
        <h1 className="page-title">User Directory</h1>
        <p className="page-subtitle">Loading users…</p>
      </header>
      <div className="user-grid">
        {Array.from({ length: 6 }, (_, index) => (
          <div key={index} className="user-card skeleton" />
        ))}
      </div>
    </main>
  );
}
