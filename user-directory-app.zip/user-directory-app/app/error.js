"use client"; // Next.js requires error boundaries to be Client Components

export default function Error({ reset }) {
  return (
    <main className="page">
      <div className="error-state" role="alert">
        <h1 className="error-title">We couldn’t load the users</h1>
        <p className="error-text">
          The API request failed. Check your internet connection and try again.
        </p>
        <button type="button" className="retry-button" onClick={() => reset()}>
          Try again
        </button>
      </div>
    </main>
  );
}
