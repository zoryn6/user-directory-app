import "./globals.css";

export const metadata = {
  title: "User Directory",
  description: "Server-rendered profile cards built with Next.js Server Components.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
